'use strict';
console.log("Navbar - Section");

let menuIcon = document.querySelector('.menu-icon');

let navbarSection = document.querySelector('.navbar-section');

menuIcon.addEventListener('click',function(){
    navbarSection.classList.toggle('active');
})